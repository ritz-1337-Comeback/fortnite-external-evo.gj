# fortnite-external-evo.gj
an open source fortnite external cheat hack what ever u want to call it called evo.gj bc evo.gg use to be the best paste ever so im going to remake it!!!
my discord: https://discord.gg/KYU9qswzA5
